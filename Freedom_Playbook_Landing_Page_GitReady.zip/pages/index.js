
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-red-900 to-yellow-700 text-white p-8 space-y-10">
      <div className="text-center">
        <h1 className="text-5xl font-bold mb-4">The Freedom Playbook</h1>
        <p className="text-xl max-w-2xl mx-auto">
          A powerful blueprint to build wealth through trucking, real estate, and passive income.
        </p>
        <div className="mt-8">
          <a href="https://www.paypal.com/ncp/payment/VHCB2ZVNDKAN6" target="_blank">
            <Button className="bg-yellow-500 text-black text-lg px-8 py-4 shadow-xl">Get Your Blueprint – $14.99</Button>
          </a>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
        <Card className="bg-white text-black">
          <CardContent className="p-6">
            <h2 className="text-xl font-bold mb-2">30-Min Zoom – $99</h2>
            <p>Quick consultation on trucking, investing, or structure planning.</p>
            <a href="https://www.paypal.com/ncp/payment/EDVA7LHXPL8TE" target="_blank">
              <Button className="mt-4 w-full">Book Now</Button>
            </a>
          </CardContent>
        </Card>
        <Card className="bg-white text-black">
          <CardContent className="p-6">
            <h2 className="text-xl font-bold mb-2">90-Min Zoom – $149.99</h2>
            <p>In-depth strategy for scaling your business, legal protection, or real estate investing.</p>
            <a href="https://www.paypal.com/ncp/payment/BNK24JVXWDTBG" target="_blank">
              <Button className="mt-4 w-full">Book Now</Button>
            </a>
          </CardContent>
        </Card>
        <Card className="bg-white text-black">
          <CardContent className="p-6">
            <h2 className="text-xl font-bold mb-2">In-Person (Memphis) – $199.99</h2>
            <p>1-on-1 guidance with Brandon Bryant. Local only. Full walkthroughs and Q&A.</p>
            <a href="https://www.paypal.com/ncp/payment/8LY2VZ9VDBKU2" target="_blank">
              <Button className="mt-4 w-full">Book Now</Button>
            </a>
          </CardContent>
        </Card>
      </div>

      <div className="text-center pt-10">
        <h3 className="text-2xl font-bold mb-2">Free Resources & Tools</h3>
        <p className="mb-4">Want free calculators and templates? Enter your email below.</p>
        <div className="flex justify-center gap-4">
          <Input placeholder="Enter your email" className="w-64 text-black" />
          <Button className="bg-yellow-500 text-black">Send Me Tools</Button>
        </div>
      </div>

      <div className="text-center pt-16">
        <h3 className="text-xl font-bold mb-4">What Others Are Saying</h3>
        <p className="italic max-w-xl mx-auto">“This playbook gave me clarity and structure. I went from driving to building my own team within 6 months!” – Real User</p>
      </div>
    </div>
  )
}
