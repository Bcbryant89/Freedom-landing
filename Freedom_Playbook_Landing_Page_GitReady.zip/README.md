# Freedom Playbook Landing Page

React-based landing page for eBook and consulting services.